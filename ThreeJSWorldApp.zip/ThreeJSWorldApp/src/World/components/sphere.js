import { SphereBufferGeometry, Mesh, MeshBasicMaterial, Color } from "../../../vendor/three/build/three.module.js";

function createSphere() {
  // create a geometry
  const geometry = new SphereBufferGeometry(1.5);

  // create a default (white) Basic material
  const material = new MeshBasicMaterial();
  


  // create a Mesh containing the geometry and material
  const sphere = new Mesh(geometry, material);

  sphere.material.color= new Color('green')
  return sphere;
}

export { createSphere };