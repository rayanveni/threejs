import { BufferGeometry, Line, LineBasicMaterial, Vector3 } from "../../../vendor/three/build/three.module.js";



function createLine() {
  
    const material = new LineBasicMaterial( { color: 0x0000ff } );
    const points =[];
    points.push(new Vector3(-10,0,0));
    points.push(new Vector3(0,10,0));   
    points.push(new Vector3(10,0,0));
    points.push(new Vector3(0,-9,0));
    points.push(new Vector3(-10,0,0));


    const geometry = new BufferGeometry().setFromPoints(points);
    // create a Mesh containing the geometry and material
    const line = new Line(geometry,material);
  
    return line;
  }
  
  export { createLine };