import {createCamera} from './components/camera.js';
import { createScene} from './components/scene.js';
import { createRenderer } from './systems/renderer.js';
import {createCube} from './components/cube.js'
import {Resizer} from './systems/Resizer.js';
import { createSphere } from './components/sphere.js';
import { createLine } from './components/line.js';


let camera, scene, renderer;

class World {
    // 1. Create an instance of the World app
    constructor(container) {

    camera = createCamera();
    scene = createScene();
    renderer = createRenderer();
    container.append(renderer.domElement);
    const cube = createCube();
    scene.add(cube);

    const sphere = createSphere();
    scene.add(sphere);

    const line = createLine();
    scene.add(line);
    
    const resizer = new Resizer(container, camera, renderer);
    
    }

   

  render() {
      renderer.render(scene,camera)
  }
    
  }
  
  export { World };